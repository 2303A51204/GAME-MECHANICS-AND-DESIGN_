using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// <summary>
/// Runs automatically the first time the project is opened. It creates all materials,
/// prefabs and both scenes (MainMenu + GameScene), wires every reference and sets up
/// the Build Settings. You can also run it again from the menu:  Archery > Build Complete Game.
/// </summary>
[InitializeOnLoad]
public static class ArcheryAutoSetup
{
    static ArcheryAutoSetup()
    {
        EditorApplication.delayCall += TryAutoBuild;
    }

    static void TryAutoBuild()
    {
        if (EditorApplication.isPlayingOrWillChangePlaymode) return;
        if (EditorApplication.isCompiling || EditorApplication.isUpdating)
        {
            EditorApplication.delayCall += TryAutoBuild;
            return;
        }
        if (File.Exists(ArcheryProjectBuilder.MenuScenePath) && File.Exists(ArcheryProjectBuilder.GameScenePath)) return;
        ArcheryProjectBuilder.BuildAll(true);
    }
}

public static class ArcheryProjectBuilder
{
    public const string MenuScenePath = "Assets/Scenes/MainMenu.unity";
    public const string GameScenePath = "Assets/Scenes/GameScene.unity";
    const string MatDir = "Assets/Materials";
    const string PrefabDir = "Assets/Prefabs";

    static readonly Dictionary<string, Material> Mats = new Dictionary<string, Material>();
    static Font uiFont;

    [MenuItem("Archery/Build Complete Game (scenes, prefabs, materials)")]
    static void BuildFromMenu()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        BuildAll(true);
    }

    // ------------------------------------------------------------------ main entry

    public static void BuildAll(bool showDialog)
    {
        try
        {
            EditorUtility.DisplayProgressBar("Archery Game Setup", "Creating folders and materials...", 0.1f);
            EnsureFolders();
            CreateMaterials();

            EditorUtility.DisplayProgressBar("Archery Game Setup", "Creating prefabs...", 0.3f);
            GameObject arrowPrefab = CreateArrowPrefab();
            GameObject bowPrefab = CreateBowPrefab(arrowPrefab);
            GameObject targetPrefab = CreateTargetPrefab();

            EditorUtility.DisplayProgressBar("Archery Game Setup", "Building MainMenu scene...", 0.55f);
            BuildMenuScene(targetPrefab);

            EditorUtility.DisplayProgressBar("Archery Game Setup", "Building GameScene...", 0.8f);
            BuildGameScene(bowPrefab, targetPrefab);

            EditorBuildSettings.scenes = new[]
            {
                new EditorBuildSettingsScene(MenuScenePath, true),
                new EditorBuildSettingsScene(GameScenePath, true)
            };

            PlayerSettings.companyName = "ArcheryStudio";
            PlayerSettings.productName = "3D Target Shooting Game - Beach";
            PlayerSettings.fullScreenMode = FullScreenMode.Windowed;
            PlayerSettings.defaultScreenWidth = 1280;
            PlayerSettings.defaultScreenHeight = 720;

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            EditorSceneManager.OpenScene(MenuScenePath);
            Debug.Log("[Archery] Setup complete. MainMenu scene is open - press Play!");
        }
        finally
        {
            EditorUtility.ClearProgressBar();
        }

        if (showDialog)
        {
            EditorUtility.DisplayDialog("3D Target Shooting Game",
                "Setup complete!\n\nThe MainMenu scene is open. Press the Play button at the top of the editor to start the game.",
                "OK");
        }
    }

    static void EnsureFolders()
    {
        string[] folders = { "Assets/Scenes", "Assets/Materials", "Assets/Prefabs", "Assets/Models", "Assets/Audio", "Assets/UI" };
        foreach (string f in folders) Directory.CreateDirectory(f);
        AssetDatabase.Refresh();
    }

    // ------------------------------------------------------------------ materials

    static void CreateMaterials()
    {
        Mats.Clear();
        Mat("Grass", new Color(0.27f, 0.55f, 0.2f), 0.05f);
        Mat("Lane", new Color(0.4f, 0.66f, 0.28f), 0.05f);
        Mat("Wood", new Color(0.55f, 0.38f, 0.2f), 0.15f);
        Mat("DarkWood", new Color(0.32f, 0.2f, 0.1f), 0.2f);
        Mat("Bark", new Color(0.38f, 0.26f, 0.15f), 0.05f);
        Mat("Leaves", new Color(0.12f, 0.42f, 0.15f), 0.05f);
        Mat("LeavesLight", new Color(0.22f, 0.52f, 0.18f), 0.05f);
        Mat("RockBlue", new Color(0.42f, 0.47f, 0.54f), 0.05f);
        Mat("RockGreen", new Color(0.3f, 0.42f, 0.3f), 0.05f);
        Mat("Snow", new Color(0.95f, 0.97f, 1f), 0.1f);
        Mat("Cloud", new Color(1f, 1f, 1f), 0f);
        Mat("Sand", new Color(0.86f, 0.7f, 0.43f), 0.02f);
        Mat("SandLane", new Color(0.93f, 0.8f, 0.55f), 0.02f);
        Mat("Dune", new Color(0.9f, 0.74f, 0.45f), 0.02f);
        Mat("Cactus", new Color(0.2f, 0.5f, 0.25f), 0.1f);
        Mat("CactusDark", new Color(0.14f, 0.4f, 0.2f), 0.1f);
        Mat("Mesa", new Color(0.72f, 0.4f, 0.22f), 0.03f);
        Mat("MesaDark", new Color(0.58f, 0.3f, 0.17f), 0.03f);
        Mat("DesertRock", new Color(0.5f, 0.42f, 0.35f), 0.05f);
        Mat("BeachSand", new Color(0.95f, 0.87f, 0.66f), 0.03f);
        Mat("BeachLane", new Color(0.98f, 0.92f, 0.76f), 0.03f);
        Mat("Ocean", new Color(0.08f, 0.5f, 0.7f), 0.85f);
        Mat("Foam", new Color(0.97f, 0.99f, 1f), 0.3f);
        Mat("PalmLeaf", new Color(0.15f, 0.56f, 0.2f), 0.15f);
        Mat("Coconut", new Color(0.3f, 0.2f, 0.1f), 0.2f);
        Mat("UmbrellaRed", new Color(0.9f, 0.2f, 0.2f), 0.1f);
        Mat("UmbrellaYellow", new Color(1f, 0.82f, 0.15f), 0.1f);
        Mat("UmbrellaBlue", new Color(0.2f, 0.5f, 0.9f), 0.1f);
        Mat("TowelPink", new Color(0.95f, 0.45f, 0.65f), 0.05f);
        Mat("TowelTeal", new Color(0.1f, 0.7f, 0.65f), 0.05f);
        Mat("MarkerWhite", new Color(0.95f, 0.95f, 0.95f), 0.1f);
        Mat("TargetYellow", new Color(1f, 0.85f, 0.1f), 0.1f);
        Mat("TargetRed", new Color(0.85f, 0.1f, 0.1f), 0.1f);
        Mat("TargetBlue", new Color(0.1f, 0.35f, 0.85f), 0.1f);
        Mat("TargetBlack", new Color(0.06f, 0.06f, 0.06f), 0.1f);
        Mat("TargetWhite", new Color(0.96f, 0.96f, 0.96f), 0.1f);
        Mat("ArrowShaft", new Color(0.75f, 0.6f, 0.38f), 0.2f);
        Mat("ArrowTip", new Color(0.7f, 0.72f, 0.75f), 0.8f);
        Mat("Feather", new Color(0.85f, 0.15f, 0.15f), 0.1f);
        Mat("BowWood", new Color(0.5f, 0.28f, 0.12f), 0.35f);
        Mat("BowGrip", new Color(0.12f, 0.1f, 0.09f), 0.1f);
        Mat("BowString", new Color(0.92f, 0.9f, 0.82f), 0.1f);

        // Procedural sky
        string skyPath = MatDir + "/Sky.mat";
        Material sky = AssetDatabase.LoadAssetAtPath<Material>(skyPath);
        if (sky == null)
        {
            Shader s = Shader.Find("Skybox/Procedural");
            if (s == null) s = Shader.Find("Standard");
            sky = new Material(s);
            AssetDatabase.CreateAsset(sky, skyPath);
        }
        if (sky.HasProperty("_SunSize")) sky.SetFloat("_SunSize", 0.07f);
        if (sky.HasProperty("_AtmosphereThickness")) sky.SetFloat("_AtmosphereThickness", 1.0f);
        if (sky.HasProperty("_Exposure")) sky.SetFloat("_Exposure", 1.25f);
        if (sky.HasProperty("_SkyTint")) sky.SetColor("_SkyTint", new Color(0.38f, 0.6f, 0.98f));
        if (sky.HasProperty("_GroundColor")) sky.SetColor("_GroundColor", new Color(0.4f, 0.7f, 0.85f));
        EditorUtility.SetDirty(sky);
        Mats["Sky"] = sky;
        AssetDatabase.SaveAssets();
    }

    static Material Mat(string name, Color color, float smoothness)
    {
        string path = MatDir + "/" + name + ".mat";
        Material m = AssetDatabase.LoadAssetAtPath<Material>(path);
        if (m == null)
        {
            Shader s = Shader.Find("Standard");
            if (s == null) s = Shader.Find("Universal Render Pipeline/Lit");
            if (s == null) s = Shader.Find("Sprites/Default");
            m = new Material(s);
            AssetDatabase.CreateAsset(m, path);
        }
        m.color = color;
        if (m.HasProperty("_Glossiness")) m.SetFloat("_Glossiness", smoothness);
        if (m.HasProperty("_Smoothness")) m.SetFloat("_Smoothness", smoothness);
        EditorUtility.SetDirty(m);
        Mats[name] = m;
        return m;
    }

    // ------------------------------------------------------------------ primitive helper

    static GameObject Prim(PrimitiveType type, string name, Transform parent, Vector3 pos, Vector3 scale,
                           string material, Vector3 euler, bool keepCollider)
    {
        GameObject go = GameObject.CreatePrimitive(type);
        go.name = name;
        go.transform.SetParent(parent, false);
        go.transform.localPosition = pos;
        go.transform.localEulerAngles = euler;
        go.transform.localScale = scale;
        go.GetComponent<Renderer>().sharedMaterial = Mats[material];
        if (!keepCollider)
        {
            Collider c = go.GetComponent<Collider>();
            if (c != null) Object.DestroyImmediate(c);
        }
        return go;
    }

    static GameObject Prim(PrimitiveType type, string name, Transform parent, Vector3 pos, Vector3 scale, string material)
    {
        return Prim(type, name, parent, pos, scale, material, Vector3.zero, false);
    }

    // ------------------------------------------------------------------ prefabs

    static void BuildArrowVisual(Transform parent)
    {
        Prim(PrimitiveType.Cylinder, "Shaft", parent, Vector3.zero, new Vector3(0.025f, 0.45f, 0.025f), "ArrowShaft", new Vector3(90f, 0f, 0f), false);
        Prim(PrimitiveType.Sphere, "Tip", parent, new Vector3(0f, 0f, 0.47f), new Vector3(0.05f, 0.05f, 0.14f), "ArrowTip");
        for (int i = 0; i < 3; i++)
        {
            Prim(PrimitiveType.Cube, "Feather" + i, parent, new Vector3(0f, 0f, -0.37f),
                 new Vector3(0.08f, 0.004f, 0.14f), "Feather", new Vector3(0f, 0f, i * 60f), false);
        }
    }

    static GameObject CreateArrowPrefab()
    {
        GameObject root = new GameObject("Arrow");
        BuildArrowVisual(root.transform);

        Rigidbody rb = root.AddComponent<Rigidbody>();
        rb.mass = 0.05f;
        rb.useGravity = true;
        rb.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
        rb.interpolation = RigidbodyInterpolation.Interpolate;

        CapsuleCollider col = root.AddComponent<CapsuleCollider>();
        col.direction = 2; // Z axis
        col.height = 0.9f;
        col.radius = 0.03f;
        col.center = new Vector3(0f, 0f, 0.05f);

        root.AddComponent<ArrowController>();

        GameObject prefab = PrefabUtility.SaveAsPrefabAsset(root, PrefabDir + "/Arrow.prefab");
        Object.DestroyImmediate(root);
        return prefab;
    }

    static GameObject CreateBowPrefab(GameObject arrowPrefab)
    {
        GameObject root = new GameObject("Bow");
        Transform t = root.transform;

        Prim(PrimitiveType.Capsule, "Handle", t, new Vector3(0f, 0f, 0.178f), new Vector3(0.06f, 0.1f, 0.06f), "BowGrip");
        Prim(PrimitiveType.Capsule, "UpperLimb", t, new Vector3(0f, 0.28f, 0.09f), new Vector3(0.045f, 0.3f, 0.045f), "BowWood", new Vector3(-17f, 0f, 0f), false);
        Prim(PrimitiveType.Capsule, "LowerLimb", t, new Vector3(0f, -0.28f, 0.09f), new Vector3(0.045f, 0.3f, 0.045f), "BowWood", new Vector3(17f, 0f, 0f), false);
        Prim(PrimitiveType.Cylinder, "String", t, Vector3.zero, new Vector3(0.008f, 0.56f, 0.008f), "BowString");

        GameObject held = new GameObject("HeldArrow");
        held.transform.SetParent(t, false);
        held.transform.localPosition = new Vector3(0f, 0.045f, 0.45f);
        BuildArrowVisual(held.transform);

        BowController bc = root.AddComponent<BowController>();
        bc.arrowPrefab = arrowPrefab;

        GameObject prefab = PrefabUtility.SaveAsPrefabAsset(root, PrefabDir + "/Bow.prefab");
        Object.DestroyImmediate(root);
        return prefab;
    }

    static GameObject CreateTargetPrefab()
    {
        float R = TargetController.TargetRadius;
        GameObject root = new GameObject("Target");
        Transform t = root.transform;

        // wooden backing board and two posts
        float boardD = 2f * (R + 0.12f);
        Prim(PrimitiveType.Cylinder, "Board", t, new Vector3(0f, 0f, 0.07f), new Vector3(boardD, 0.03f, boardD), "DarkWood", new Vector3(90f, 0f, 0f), false);
        Prim(PrimitiveType.Cube, "PostLeft", t, new Vector3(-0.55f, -0.85f, 0.2f), new Vector3(0.1f, 1.5f, 0.1f), "Wood");
        Prim(PrimitiveType.Cube, "PostRight", t, new Vector3(0.55f, -0.85f, 0.2f), new Vector3(0.1f, 1.5f, 0.1f), "Wood");

        // rings: white (outer) first, yellow (centre) last so inner rings sit in front
        string[] ringMats = { "TargetYellow", "TargetRed", "TargetBlue", "TargetBlack", "TargetWhite" };
        for (int j = TargetController.RingFractions.Length - 1; j >= 0; j--)
        {
            float d = 2f * R * TargetController.RingFractions[j];
            float z = -0.012f * (TargetController.RingFractions.Length - 1 - j);
            GameObject ring = Prim(PrimitiveType.Cylinder, "Ring_" + TargetController.RingPoints[j] + "pts", t,
                                   new Vector3(0f, 0f, z), new Vector3(d, 0.025f, d), ringMats[j],
                                   new Vector3(90f, 0f, 0f), false);
            if (j == TargetController.RingFractions.Length - 1)
            {
                // Only the outer white disc has a collider; scoring is calculated from the hit position.
                MeshCollider mc = ring.AddComponent<MeshCollider>();
                mc.sharedMesh = ring.GetComponent<MeshFilter>().sharedMesh;
            }
        }

        root.AddComponent<TargetController>();

        GameObject prefab = PrefabUtility.SaveAsPrefabAsset(root, PrefabDir + "/Target.prefab");
        Object.DestroyImmediate(root);
        return prefab;
    }

    // ------------------------------------------------------------------ environment

    static void BuildEnvironment()
    {
        // Light: bright tropical sun
        GameObject sunGo = new GameObject("Sun");
        Light sun = sunGo.AddComponent<Light>();
        sun.type = LightType.Directional;
        sun.color = new Color(1f, 0.97f, 0.88f);
        sun.intensity = 1.25f;
        sun.shadows = LightShadows.Soft;
        sunGo.transform.rotation = Quaternion.Euler(52f, -30f, 0f);

        RenderSettings.sun = sun;
        RenderSettings.skybox = Mats["Sky"];
        RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Skybox;
        RenderSettings.fog = true;
        RenderSettings.fogMode = FogMode.Exponential;
        RenderSettings.fogDensity = 0.0025f;
        RenderSettings.fogColor = new Color(0.74f, 0.87f, 0.96f);
        DynamicGI.UpdateEnvironment();

        Transform env = new GameObject("Environment").transform;

        // Ocean everywhere, sand beach on top of it
        Prim(PrimitiveType.Cube, "Ocean", env, new Vector3(0f, -0.8f, 0f), new Vector3(1600f, 1f, 1600f), "Ocean", Vector3.zero, true);
        Prim(PrimitiveType.Cube, "Beach", env, new Vector3(-155f, -0.5f, 300f), new Vector3(400f, 1f, 700f), "BeachSand", Vector3.zero, true);
        Prim(PrimitiveType.Cube, "Lane", env, new Vector3(0f, 0.01f, 30f), new Vector3(30f, 0.02f, 70f), "BeachLane");
        Prim(PrimitiveType.Cube, "ShootingPlatform", env, new Vector3(0f, 0.075f, 0f), new Vector3(6f, 0.15f, 3f), "Wood");

        // Surf foam along the shoreline (right side of the range)
        Prim(PrimitiveType.Cube, "Foam1", env, new Vector3(44.5f, 0.01f, 300f), new Vector3(2.5f, 0.02f, 700f), "Foam");
        Prim(PrimitiveType.Cube, "Foam2", env, new Vector3(49f, -0.28f, 300f), new Vector3(1.2f, 0.02f, 700f), "Foam");
        Prim(PrimitiveType.Cube, "Foam3", env, new Vector3(58f, -0.28f, 300f), new Vector3(0.8f, 0.02f, 700f), "Foam");

        float[] lines = { 15f, 25f, 30f, 40f };
        foreach (float z in lines)
        {
            Prim(PrimitiveType.Cube, "Line_" + z + "m", env, new Vector3(0.5f, 0.025f, z - 3.5f), new Vector3(24f, 0.01f, 0.2f), "MarkerWhite");
        }

        Random.InitState(1234);

        // Palm trees
        Transform palms = new GameObject("PalmTrees").transform;
        palms.SetParent(env, false);
        int placed = 0;
        while (placed < 45)
        {
            float x = Random.Range(-70f, 40f);
            float z = Random.Range(-15f, 110f);
            if (Mathf.Abs(x) < 14f && z < 55f) continue; // keep the lane clear
            BuildPalm(palms, new Vector3(x, 0f, z), Random.Range(0.9f, 1.4f));
            placed++;
        }

        // Beach umbrellas, towels and balls
        Transform props = new GameObject("BeachProps").transform;
        props.SetParent(env, false);
        string[] umbrellaMats = { "UmbrellaRed", "UmbrellaYellow", "UmbrellaBlue" };
        string[] towelMats = { "TowelPink", "TowelTeal", "UmbrellaYellow" };
        placed = 0;
        while (placed < 10)
        {
            float x = Random.Range(-45f, 38f);
            float z = Random.Range(-5f, 70f);
            if (Mathf.Abs(x) < 15f && z < 55f) continue;
            GameObject u = new GameObject("Umbrella");
            u.transform.SetParent(props, false);
            u.transform.localPosition = new Vector3(x, 0f, z);
            u.transform.localRotation = Quaternion.Euler(0f, 0f, Random.Range(-8f, 8f));
            Prim(PrimitiveType.Cylinder, "Pole", u.transform, new Vector3(0f, 1.1f, 0f), new Vector3(0.05f, 1.1f, 0.05f), "MarkerWhite");
            Prim(PrimitiveType.Sphere, "Canopy", u.transform, new Vector3(0f, 2.2f, 0f), new Vector3(2.6f, 0.9f, 2.6f), umbrellaMats[placed % 3]);
            Prim(PrimitiveType.Cube, "Towel", props, new Vector3(x + 1.4f, 0.02f, z), new Vector3(1.0f, 0.03f, 2.0f), towelMats[placed % 3],
                 new Vector3(0f, Random.Range(-30f, 30f), 0f), false);
            if (placed % 3 == 0)
            {
                Prim(PrimitiveType.Sphere, "BeachBall", props, new Vector3(x - 1.8f, 0.25f, z + 0.5f), Vector3.one * 0.5f, "UmbrellaRed");
            }
            placed++;
        }

        // Distant islands
        Transform islands = new GameObject("Islands").transform;
        islands.SetParent(env, false);
        Vector3[] islandPos = { new Vector3(230f, 0f, 120f), new Vector3(320f, 0f, 260f), new Vector3(260f, 0f, 420f), new Vector3(180f, 0f, 560f) };
        for (int i = 0; i < islandPos.Length; i++)
        {
            float w = Random.Range(70f, 120f);
            Prim(PrimitiveType.Sphere, "IslandSand" + i, islands, islandPos[i], new Vector3(w * 1.3f, 14f, w * 1.1f), "BeachSand");
            Prim(PrimitiveType.Sphere, "IslandHill" + i, islands, islandPos[i] + new Vector3(0f, 2f, 0f), new Vector3(w, Random.Range(35f, 60f), w * 0.85f), "Leaves");
        }

        // Far green hills behind the beach
        Transform hills = new GameObject("Hills").transform;
        hills.SetParent(env, false);
        Vector3[] hillPos = { new Vector3(-380f, 0f, 150f), new Vector3(-300f, 0f, 380f), new Vector3(-80f, 0f, 560f), new Vector3(-420f, 0f, -80f) };
        for (int i = 0; i < hillPos.Length; i++)
        {
            Prim(PrimitiveType.Sphere, "Hill" + i, hills, hillPos[i], new Vector3(320f, Random.Range(130f, 200f), 300f), i % 2 == 0 ? "RockGreen" : "RockBlue");
        }

        // Fluffy clouds
        Transform clouds = new GameObject("Clouds").transform;
        clouds.SetParent(env, false);
        for (int i = 0; i < 10; i++)
        {
            Vector3 pos = new Vector3(Random.Range(-350f, 350f), Random.Range(140f, 210f), Random.Range(-50f, 400f));
            GameObject c = Prim(PrimitiveType.Sphere, "Cloud" + i, clouds, pos,
                                new Vector3(Random.Range(70f, 130f), Random.Range(12f, 20f), Random.Range(35f, 55f)), "Cloud");
            c.GetComponent<Renderer>().shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
        }
    }

    static void BuildPalm(Transform parent, Vector3 pos, float s)
    {
        GameObject palm = new GameObject("Palm");
        palm.transform.SetParent(parent, false);
        palm.transform.localPosition = pos;
        palm.transform.localRotation = Quaternion.Euler(0f, Random.Range(0f, 360f), 0f);

        // slightly leaning trunk (top ends at about x = 0.7s, y = 5.7s)
        Prim(PrimitiveType.Capsule, "Trunk", palm.transform, new Vector3(0.35f * s, 2.8f * s, 0f), new Vector3(0.3f * s, 2.9f * s, 0.3f * s), "Bark", new Vector3(0f, 0f, -7f), false);

        GameObject crown = new GameObject("Crown");
        crown.transform.SetParent(palm.transform, false);
        crown.transform.localPosition = new Vector3(0.7f * s, 5.65f * s, 0f);

        for (int i = 0; i < 7; i++)
        {
            GameObject pivot = new GameObject("Frond" + i);
            pivot.transform.SetParent(crown.transform, false);
            pivot.transform.localRotation = Quaternion.Euler(0f, i * 51.4f, 0f);
            Prim(PrimitiveType.Cube, "Blade", pivot.transform, new Vector3(0f, -0.25f * s, 1.1f * s), new Vector3(0.7f * s, 0.05f * s, 2.4f * s), "PalmLeaf", new Vector3(18f, 0f, 0f), false);
        }
        Prim(PrimitiveType.Sphere, "Coconut1", crown.transform, new Vector3(0.15f * s, -0.3f * s, 0.1f * s), Vector3.one * 0.3f * s, "Coconut");
        Prim(PrimitiveType.Sphere, "Coconut2", crown.transform, new Vector3(-0.15f * s, -0.3f * s, -0.1f * s), Vector3.one * 0.3f * s, "Coconut");
    }

    // ------------------------------------------------------------------ scenes

    static void BuildMenuScene(GameObject targetPrefab)
    {
        EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        BuildEnvironment();

        GameObject camGo = new GameObject("Main Camera");
        camGo.tag = "MainCamera";
        camGo.transform.position = new Vector3(0f, 1.7f, 0f);
        Camera cam = camGo.AddComponent<Camera>();
        cam.clearFlags = CameraClearFlags.Skybox;
        cam.fieldOfView = 60f;
        cam.farClipPlane = 1500f;
        camGo.AddComponent<AudioListener>();

        GameObject target = (GameObject)PrefabUtility.InstantiatePrefab(targetPrefab);
        target.name = "MenuTarget";
        target.transform.position = new Vector3(5.5f, 1.6f, 10f);

        GameObject audio = new GameObject("AudioManager");
        audio.AddComponent<AudioManager>();

        // UI
        Canvas canvas = MakeCanvas("Canvas");
        MenuUI menu = canvas.gameObject.AddComponent<MenuUI>();
        menu.swayingTarget = target.transform;

        Text title = MakeText(canvas.transform, "Title", "3D TARGET SHOOTING GAME", 84, Color.white,
                              new Vector2(0.5f, 1f), new Vector2(0f, -110f), new Vector2(1500f, 120f), TextAnchor.MiddleCenter);
        title.fontStyle = FontStyle.Bold;
        Text subtitle = MakeText(canvas.transform, "Subtitle", "ARROW  -  Beach Edition", 44, new Color(1f, 0.85f, 0.2f),
                                 new Vector2(0.5f, 1f), new Vector2(0f, -210f), new Vector2(1000f, 70f), TextAnchor.MiddleCenter);
        subtitle.fontStyle = FontStyle.Bold;

        RectTransform mainPanel = MakeImage(canvas.transform, "MainPanel", new Color(0f, 0f, 0f, 0.4f),
                                            new Vector2(0.5f, 0.5f), new Vector2(0f, -90f), new Vector2(620f, 560f)).rectTransform;
        menu.mainPanel = mainPanel.gameObject;
        menu.startButton = MakeButton(mainPanel, "StartButton", "START GAME", new Vector2(0.5f, 0.5f), new Vector2(0f, 170f), new Vector2(460f, 90f), new Color(0.2f, 0.65f, 0.25f));
        menu.instructionsButton = MakeButton(mainPanel, "HowToPlayButton", "HOW TO PLAY", new Vector2(0.5f, 0.5f), new Vector2(0f, 55f), new Vector2(460f, 90f), new Color(0.2f, 0.45f, 0.8f));
        menu.quitButton = MakeButton(mainPanel, "QuitButton", "QUIT", new Vector2(0.5f, 0.5f), new Vector2(0f, -60f), new Vector2(460f, 90f), new Color(0.7f, 0.25f, 0.2f));
        menu.highScoreText = MakeText(mainPanel, "BestScore", "Best Score: 0", 38, new Color(1f, 0.85f, 0.2f),
                                      new Vector2(0.5f, 0.5f), new Vector2(0f, -180f), new Vector2(500f, 60f), TextAnchor.MiddleCenter);

        RectTransform instr = MakeImage(canvas.transform, "InstructionsPanel", new Color(0f, 0f, 0f, 0.8f),
                                        new Vector2(0.5f, 0.5f), new Vector2(0f, -70f), new Vector2(1200f, 760f)).rectTransform;
        menu.instructionsPanel = instr.gameObject;
        MakeText(instr, "InstrTitle", "HOW TO PLAY", 64, new Color(1f, 0.85f, 0.2f),
                 new Vector2(0.5f, 1f), new Vector2(0f, -30f), new Vector2(1000f, 90f), TextAnchor.MiddleCenter);
        string body =
            "Mouse Move  -  Aim the bow\n" +
            "Left Click  -  Shoot an arrow\n" +
            "Right Mouse (hold)  -  Zoom in\n" +
            "R  -  Restart the game\n" +
            "Esc or P  -  Pause / resume\n\n" +
            "You have 10 arrows per round. Arrows drop a little with\n" +
            "distance, so aim slightly higher at far targets.\n\n" +
            "SCORING:  Yellow centre = 10   Red = 8   Blue = 6\n" +
            "Black = 4   White = 2.   Score 60 or more to WIN!";
        MakeText(instr, "InstrBody", body, 36, Color.white,
                 new Vector2(0.5f, 0.5f), new Vector2(0f, 10f), new Vector2(1100f, 520f), TextAnchor.UpperLeft);
        menu.backButton = MakeButton(instr, "BackButton", "BACK", new Vector2(0.5f, 0f), new Vector2(0f, 70f), new Vector2(320f, 80f), new Color(0.2f, 0.45f, 0.8f));

        CreateEventSystem();
        EditorSceneManager.SaveScene(EditorSceneManager.GetActiveScene(), MenuScenePath);
    }

    static void BuildGameScene(GameObject bowPrefab, GameObject targetPrefab)
    {
        EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        BuildEnvironment();

        // Player + camera
        GameObject player = new GameObject("Player");
        player.transform.position = new Vector3(0f, 0.15f, 0f);

        GameObject camGo = new GameObject("Main Camera");
        camGo.tag = "MainCamera";
        camGo.transform.SetParent(player.transform, false);
        camGo.transform.localPosition = new Vector3(0f, 1.65f, 0f);
        Camera cam = camGo.AddComponent<Camera>();
        cam.clearFlags = CameraClearFlags.Skybox;
        cam.fieldOfView = 60f;
        cam.nearClipPlane = 0.05f;
        cam.farClipPlane = 1500f;
        camGo.AddComponent<AudioListener>();

        PlayerController pc = player.AddComponent<PlayerController>();
        pc.cameraTransform = camGo.transform;

        // Bow in front of the camera
        GameObject bow = (GameObject)PrefabUtility.InstantiatePrefab(bowPrefab);
        bow.transform.SetParent(camGo.transform, false);
        bow.transform.localPosition = new Vector3(-0.28f, -0.22f, 0.6f);
        bow.transform.localRotation = Quaternion.Euler(0f, 6f, 0f);
        bow.transform.localScale = Vector3.one * 0.35f;

        // Targets at different distances
        Vector3[] positions =
        {
            new Vector3(0f, 1.5f, 15f),
            new Vector3(-8f, 1.5f, 25f),
            new Vector3(9f, 1.5f, 30f),
            new Vector3(0f, 1.5f, 40f)
        };
        Transform targets = new GameObject("Targets").transform;
        for (int i = 0; i < positions.Length; i++)
        {
            GameObject t = (GameObject)PrefabUtility.InstantiatePrefab(targetPrefab);
            t.name = "Target_" + (i + 1) + "_" + Mathf.RoundToInt(positions[i].z) + "m";
            t.transform.SetParent(targets, false);
            t.transform.position = positions[i];
        }

        // Managers
        GameObject audio = new GameObject("AudioManager");
        audio.AddComponent<AudioManager>();

        // UI
        Canvas canvas = MakeCanvas("Canvas");
        UIManager ui = canvas.gameObject.AddComponent<UIManager>();

        // HUD
        RectTransform hud = MakeRect("HUD", canvas.transform);
        Stretch(hud);
        ui.hudPanel = hud.gameObject;

        RectTransform scorePanel = MakeImage(hud, "ScorePanel", new Color(0f, 0f, 0f, 0.45f), new Vector2(0f, 1f), new Vector2(30f, -30f), new Vector2(400f, 90f)).rectTransform;
        ui.scoreText = MakeText(scorePanel, "ScoreText", "Score: 0", 52, Color.white, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(380f, 80f), TextAnchor.MiddleCenter);

        RectTransform arrowPanel = MakeImage(hud, "ArrowsPanel", new Color(0f, 0f, 0f, 0.45f), new Vector2(1f, 1f), new Vector2(-30f, -30f), new Vector2(460f, 90f)).rectTransform;
        ui.arrowsText = MakeText(arrowPanel, "ArrowsText", "Arrows: 10 / 10", 52, Color.white, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(440f, 80f), TextAnchor.MiddleCenter);

        ui.hitText = MakeText(hud, "HitText", "", 72, Color.white, new Vector2(0.5f, 0.5f), new Vector2(0f, 170f), new Vector2(900f, 110f), TextAnchor.MiddleCenter);
        ui.hitText.fontStyle = FontStyle.Bold;

        MakeText(hud, "ControlsHint", "Mouse: Aim   |   Left Click: Shoot   |   Right Mouse: Zoom   |   R: Restart   |   Esc/P: Pause",
                 26, new Color(1f, 1f, 1f, 0.85f), new Vector2(0.5f, 0f), new Vector2(0f, 20f), new Vector2(1600f, 40f), TextAnchor.MiddleCenter);

        // Crosshair
        Color cross = new Color(1f, 1f, 1f, 0.95f);
        Vector2 mid = new Vector2(0.5f, 0.5f);
        MakeImage(hud, "CrossLeft", cross, mid, new Vector2(-18f, 0f), new Vector2(14f, 3f));
        MakeImage(hud, "CrossRight", cross, mid, new Vector2(18f, 0f), new Vector2(14f, 3f));
        MakeImage(hud, "CrossUp", cross, mid, new Vector2(0f, 18f), new Vector2(3f, 14f));
        MakeImage(hud, "CrossDown", cross, mid, new Vector2(0f, -18f), new Vector2(3f, 14f));
        MakeImage(hud, "CrossDot", new Color(1f, 0.2f, 0.2f, 1f), mid, Vector2.zero, new Vector2(5f, 5f));

        // Pause panel
        RectTransform pause = MakeImage(canvas.transform, "PausePanel", new Color(0f, 0f, 0f, 0.65f), mid, Vector2.zero, Vector2.one).rectTransform;
        Stretch(pause);
        ui.pausePanel = pause.gameObject;
        Text pauseTitle = MakeText(pause, "PauseTitle", "PAUSED", 100, Color.white, mid, new Vector2(0f, 240f), new Vector2(900f, 130f), TextAnchor.MiddleCenter);
        pauseTitle.fontStyle = FontStyle.Bold;
        ui.resumeButton = MakeButton(pause, "ResumeButton", "RESUME", mid, new Vector2(0f, 70f), new Vector2(460f, 90f), new Color(0.2f, 0.65f, 0.25f));
        ui.pauseRestartButton = MakeButton(pause, "RestartButton", "RESTART GAME", mid, new Vector2(0f, -40f), new Vector2(460f, 90f), new Color(0.2f, 0.45f, 0.8f));
        ui.pauseMenuButton = MakeButton(pause, "MainMenuButton", "MAIN MENU", mid, new Vector2(0f, -150f), new Vector2(460f, 90f), new Color(0.7f, 0.25f, 0.2f));

        // Game over panel
        RectTransform over = MakeImage(canvas.transform, "GameOverPanel", new Color(0f, 0f, 0f, 0.7f), mid, Vector2.zero, Vector2.one).rectTransform;
        Stretch(over);
        ui.gameOverPanel = over.gameObject;
        Text overTitle = MakeText(over, "GameOverTitle", "GAME OVER", 110, new Color(1f, 0.85f, 0.2f), mid, new Vector2(0f, 280f), new Vector2(1000f, 140f), TextAnchor.MiddleCenter);
        overTitle.fontStyle = FontStyle.Bold;
        ui.finalScoreText = MakeText(over, "FinalScore", "Final Score: 0", 72, Color.white, mid, new Vector2(0f, 140f), new Vector2(1000f, 100f), TextAnchor.MiddleCenter);
        ui.resultText = MakeText(over, "ResultMessage", "", 46, new Color(0.6f, 1f, 0.6f), mid, new Vector2(0f, 40f), new Vector2(1500f, 70f), TextAnchor.MiddleCenter);
        ui.highScoreText = MakeText(over, "HighScore", "", 40, new Color(1f, 0.85f, 0.2f), mid, new Vector2(0f, -35f), new Vector2(1000f, 60f), TextAnchor.MiddleCenter);
        ui.overRestartButton = MakeButton(over, "RestartButton", "RESTART GAME", mid, new Vector2(0f, -140f), new Vector2(460f, 90f), new Color(0.2f, 0.65f, 0.25f));
        ui.overMenuButton = MakeButton(over, "MainMenuButton", "MAIN MENU", mid, new Vector2(0f, -250f), new Vector2(460f, 90f), new Color(0.7f, 0.25f, 0.2f));

        pause.gameObject.SetActive(false);
        over.gameObject.SetActive(false);

        CreateEventSystem();

        // Game manager (created last so every reference exists)
        GameObject gmGo = new GameObject("GameManager");
        ScoreManager score = gmGo.AddComponent<ScoreManager>();
        GameManager gm = gmGo.AddComponent<GameManager>();
        gm.scoreManager = score;
        gm.uiManager = ui;

        EditorSceneManager.SaveScene(EditorSceneManager.GetActiveScene(), GameScenePath);
    }

    // ------------------------------------------------------------------ UI helpers

    static Font UIFont
    {
        get
        {
            if (uiFont == null) uiFont = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            return uiFont;
        }
    }

    static Canvas MakeCanvas(string name)
    {
        GameObject go = new GameObject(name, typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        Canvas canvas = go.GetComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        CanvasScaler scaler = go.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920f, 1080f);
        scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
        scaler.matchWidthOrHeight = 0.5f;
        return canvas;
    }

    static void CreateEventSystem()
    {
        new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));
    }

    static RectTransform MakeRect(string name, Transform parent)
    {
        GameObject go = new GameObject(name, typeof(RectTransform));
        go.transform.SetParent(parent, false);
        return go.GetComponent<RectTransform>();
    }

    static void Stretch(RectTransform rt)
    {
        rt.anchorMin = Vector2.zero;
        rt.anchorMax = Vector2.one;
        rt.offsetMin = Vector2.zero;
        rt.offsetMax = Vector2.zero;
    }

    static Image MakeImage(Transform parent, string name, Color color, Vector2 anchor, Vector2 pos, Vector2 size)
    {
        RectTransform rt = MakeRect(name, parent);
        Image img = rt.gameObject.AddComponent<Image>();
        img.color = color;
        rt.anchorMin = anchor;
        rt.anchorMax = anchor;
        rt.pivot = anchor;
        rt.anchoredPosition = pos;
        rt.sizeDelta = size;
        return img;
    }

    static Text MakeText(Transform parent, string name, string content, int size, Color color,
                         Vector2 anchor, Vector2 pos, Vector2 boxSize, TextAnchor align)
    {
        RectTransform rt = MakeRect(name, parent);
        Text text = rt.gameObject.AddComponent<Text>();
        text.font = UIFont;
        text.text = content;
        text.fontSize = size;
        text.color = color;
        text.alignment = align;
        text.horizontalOverflow = HorizontalWrapMode.Wrap;
        text.verticalOverflow = VerticalWrapMode.Overflow;
        text.raycastTarget = false;
        rt.anchorMin = anchor;
        rt.anchorMax = anchor;
        rt.pivot = anchor;
        rt.anchoredPosition = pos;
        rt.sizeDelta = boxSize;

        Shadow shadow = rt.gameObject.AddComponent<Shadow>();
        shadow.effectColor = new Color(0f, 0f, 0f, 0.7f);
        shadow.effectDistance = new Vector2(2f, -2f);
        return text;
    }

    static Button MakeButton(Transform parent, string name, string label, Vector2 anchor, Vector2 pos, Vector2 size, Color color)
    {
        Image img = MakeImage(parent, name, color, anchor, pos, size);
        Button button = img.gameObject.AddComponent<Button>();
        button.targetGraphic = img;

        Text text = MakeText(img.transform, "Label", label, 38, Color.white, new Vector2(0.5f, 0.5f), Vector2.zero, size, TextAnchor.MiddleCenter);
        text.fontStyle = FontStyle.Bold;
        return button;
    }
}
